# -*- coding: utf-8 -*-
"""
Created on Mon Jun 18 13:21:45 2018

@author: User
"""

if __name__ == "__main__":
     test = Testing()
     test.test()