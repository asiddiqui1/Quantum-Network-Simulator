# Quantum Network Simulator

Corey Matyas, Aliza Siddiqui, 2018

## Dependencies
* Python 3.6 (or probably any Python3)
* numpy
* NetworkX 2.1+
* matplotlib

## Running
```
pip install -r requirements.txt
python qns/qns.py
```
